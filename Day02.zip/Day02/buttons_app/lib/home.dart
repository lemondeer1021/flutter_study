import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buttons'),
        backgroundColor: Colors.amber,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextButton(
              onLongPress: () {
                print("loooooong");
              },
              onPressed: () {
                // print('textbutton is clicked!');
                int num1 = 10;
                int num2 = 20;
                print("${num1 + num2}");
              },
              style: TextButton.styleFrom(
                foregroundColor: Colors.red,

              ),
              child: const Text(
                'Text Button',
                style: TextStyle(
                  fontSize: 20,
                ),
              )
            ),



            ElevatedButton(
              onPressed: () {
                print('elevated button clicked');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)
                )
              ), 
              child: const Text(
                'Elevated Button'
              )
            ),



            OutlinedButton(
              onPressed: () {
                print('outlined button clicked');
              }, 
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.green,
                backgroundColor: Colors.amber,
                side: const BorderSide(
                  color: Colors.black,
                  width: 2.0
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)
                )
              ),
              child: const Text('Outlined Button'),
            ),



            TextButton.icon(
              onPressed: (){

              }, 
              style: TextButton.styleFrom(
                foregroundColor: Colors.black
              ),
              icon: const Icon(
                Icons.home,
                size: 40,
                color: Colors.red,
              ), 
              label: const Text(
                'go to home'
              )
            ),



            ElevatedButton.icon(
              onPressed: (){

              }, 
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.orange,
                minimumSize: const Size(150, 40),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)
                )
              ),
              icon: const Icon(
                Icons.home,
                color: Colors.deepOrange,
              ), 
              label: const Text(
                'Button',
                style: TextStyle(color: Colors.deepPurple),
              ),
            ),



            
          ],
        ),
      ),
    );
  }
}

