import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber,
      appBar: AppBar(
        title: const Text('영웅 Card'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body:  Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: CircleAvatar(
                backgroundImage: AssetImage('images/lee.jpg'),
                radius: 100,
              ),
            ),
            const Divider(
              thickness: 2,
              // height: 30,
              color: Colors.brown,
            ),
            const Text(
              '성웅',
              style: TextStyle(color: Colors.white,letterSpacing: 1,),
            ),
            const Text(
              '이순신 장군',
              style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
            const Text(
              '전적',
              style: TextStyle(color: Colors.white,letterSpacing: 1,),
            ),
            const Text(
              '62전 62승',
              style: TextStyle(
                  color: Colors.red,
                  letterSpacing: 2,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
            const Row(
              children: [
                Icon(Icons.check_circle_outline),
                Padding(
                  padding: EdgeInsets.fromLTRB(8, 0, 0, 0),
                  child: Text('옥포해전'),
                ),
              ],
            ),
            const Row(
              children: [
                Icon(Icons.check_circle_outline),
                Padding(
                  padding: EdgeInsets.fromLTRB(8, 0, 0, 0),
                  child: Text('사천포해전'),
                ),
              ],
            ),
            const Row(
              children: [
                Icon(Icons.check_circle_outline),
                Padding(
                  padding: EdgeInsets.fromLTRB(8, 0, 0, 0),
                  child: Text('당포해전'),
                ),
              ],
            ),
            const Row(
              children: [
                Icon(Icons.check_circle_outline),
                Padding(
                  padding: EdgeInsets.fromLTRB(8, 0, 0, 0),
                  child: Text('한산도대첩'),
                ),
              ],
            ),
            const Row(
              children: [
                Icon(Icons.check_circle_outline),
                Padding(
                  padding: EdgeInsets.fromLTRB(8, 0, 0, 0),
                  child: Text('부산포해전'),
                ),
              ],
            ),
            const Row(
              children: [
                Icon(Icons.check_circle_outline),
                Padding(
                  padding: EdgeInsets.fromLTRB(8, 0, 0, 0),
                  child: Text('명량해전'),
                ),
              ],
            ),
            Center(child: Image.asset('images/turtle.gif', width: 70,)),
          ],
          
        ),
      ),
    );
  }
}
