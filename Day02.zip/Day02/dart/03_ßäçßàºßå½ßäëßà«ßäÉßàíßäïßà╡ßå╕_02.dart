main() {
  //문자열, dart에서는 ', " 구분 안함
  String str1 = "유비";
  String str2 = '장비';

  //문자열 연결 방식으로 출력
  print(str1 +" : "+ str2);

  print("$str1 : $str2");

  int intNum1 = 170;
  int intNum2 = 70;

  print("intNum1과 intNum2의 합은 ${intNum1 + intNum2} 입니다.");
}