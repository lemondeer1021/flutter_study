main() {
  //var : 데이터에 의한 추론형 변수 선언
  var name = '유비';
  print(name);
  print("이름 : $name");

}