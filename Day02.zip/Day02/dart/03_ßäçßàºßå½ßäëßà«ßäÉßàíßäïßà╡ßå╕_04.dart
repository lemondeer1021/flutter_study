main() {
  //var와 dynamic
  var name = "유비";
  name = "관우";
  // name = 10000; //var는 String으로 지정되었기때문에 int 형 할당 불가능
  print(name);

  dynamic name1 = "장비";
  name1 = "유비";
  name1 = 100; //dynamic은 메모리를 조금 더 많이 차지하는 대신 할당 가능
  
  int num1 = 100;
  print(name1 + num1 ); //가능은 하지만 권장하진 않음

}