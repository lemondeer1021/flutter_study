main() {
  //List collection
  List kingdoms = [];

  //List에 데이터 추가하기
  kingdoms.add("위");
  kingdoms.add("촉");
  kingdoms.add("오");

  print("리스트 출력 : $kingdoms");

  //원하는 데이터만 출력하기
  print("0번째 출력 : ${kingdoms[0]}");

  //원하는 데이터 수정하기
  kingdoms[0] = 'we';
  print("위를 we로 변경 : $kingdoms");

  //원하는 데이터 삭제하기
  // 1.번지수(index)로 삭제하기
  kingdoms.removeAt(0);
  print("0번째 삭제 : $kingdoms");

  // 2.값으로 삭제하기
  kingdoms.remove("촉");
  print("촉값 삭제 $kingdoms");


  //리스트 데이터 갯수 
  print("리스트 갯수 : ${kingdoms.length}");


  kingdoms.add(1);
  print(kingdoms);

  //List에 정해진 변수 타입의 데이터만 추가하기
  List<String> kingdoms2 = [];
  kingdoms2.add('고려');
  // kingdoms2.add(1); //에러
  print("kingdoms2 리스트 : $kingdoms2");

  //List선언시 초기값 할당
  List<String> kingdoms3 = ['we', '촉', '오'];
  print("kingdoms3 리스트 : $kingdoms3");

}