main() {
  //final 과 const
  String name1 = "유비";
  name1 = '장비';
  print(name1);

  final String name2 = '관루';
  // name2 = '조조';
  print(name2);

  final String name22;
  name22 = '33';
  print(name22);


  const String name3 = '조자룡';
  // name3 = '조조';
  print(name3);
  
  // const String name33;
  // name33 = '22';
  // print(name33);

  //final과 const의 차이점
  //final은 실행시 결정되는 값으로 설정된다.
  final DateTime now1 = DateTime.now();
  print(now1);

  //const는 컴파일 될때 결정되는 값으로 설정된다.
  // const DateTime now2 = DateTime.now();

}