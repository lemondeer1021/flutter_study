main() {
  //Map => key, value로 이루어진 Collection
  Map fruits = {
    'apple' : '사과',
    'grape' : '포도',
    'banana' : '바나나'
  };
  print(fruits);

  //데이터 추가하기
  fruits['melon'] = '멜론';
  print(fruits);

  //데이터 조회
  print(fruits['apple']);

  //데이터 수정
  fruits['apple'] = '맛있는 사과';
  print(fruits);

  //데이터 삭제
  fruits.remove('banana');
  print(fruits);

  //Generic을 선언하여 Map 구성하기
  Map<String, int> fruitsPrice = {
    'banana':1000,
    'apple':10000,
    'orange':500,
  };
  print(fruitsPrice['banana']);

  //널 허용
  int? applePrice1 = fruitsPrice['apple'];
  print(applePrice1);

  //값에 널이 없다고 확신
  int applePrice2 = fruitsPrice['apple']!;
  print(applePrice2);

  print(fruitsPrice['apple']! + fruitsPrice['banana']!);

}