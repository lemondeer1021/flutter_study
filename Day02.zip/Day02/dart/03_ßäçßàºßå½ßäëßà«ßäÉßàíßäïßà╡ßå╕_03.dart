main() {
  //Boolean
  bool isTrue = true;
  bool isFalse = false;

  print("bool은 $isTrue와 $isFalse만을 가지고 있습니다.");
}