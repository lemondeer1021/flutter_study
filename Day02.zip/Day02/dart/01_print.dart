main() {
  // 화면 출력
  print('test');
  print('world');
}