main() {
  //변수 타입 선어자
  //정수
  int intNum1 = 30;
  print(intNum1);

  int intNum2 = 12;
  print(intNum2);

  print("intNum1 + intNum2 = ${intNum1 + intNum2}");
  print("intNum1 - intNum2 = ${intNum1 - intNum2}");
  print("intNum1 * intNum2 = ${intNum1 * intNum2}");
  print("intNum1 / intNum2 = ${intNum1 / intNum2}");
  print("intNum1 % intNum2 = ${intNum1 % intNum2}"); //나머지
  print("intNum1 ~/ intNum2 = ${intNum1 ~/ intNum2}"); //몫


  //실수
  double doubleNum1 = 1.5;
  double doubleNum2 = 0.2;

  print("doubleNum1 + doubleNum2 = ${doubleNum1 + doubleNum2}");
  print("doubleNum1 - doubleNum2 = ${doubleNum1 - doubleNum2}");
  print("doubleNum1 * doubleNum2 = ${doubleNum1 * doubleNum2}");
  print("doubleNum1 / doubleNum2 = ${doubleNum1 / doubleNum2}");
  print("doubleNum1 % doubleNum2 = ${doubleNum1 % doubleNum2}"); //나머지
  print("doubleNum1 ~/ doubleNum2 = ${doubleNum1 ~/ doubleNum2}"); //몫

}