import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Images Test"),
        backgroundColor: Colors.amber,
        foregroundColor: Colors.white,
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'images/smile.png',
                width: 150,
                fit: BoxFit.contain,
              ),
              Image.asset(
                'images/smile.png',
                width: 50,
                height:100,
                fit: BoxFit.fill,
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'images/smile.png',
                      width: 50,
                      height: 50,
                    ),
                    
                  ],
                ),
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
              Image.asset(
                'images/smile.png',
                width: 100,
              ),
            ],
          ),
        ),
      ),
    );
  }
}