import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Text Row"),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: const Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.all(20.0),
              child: Text("James"),
            ),
            Padding(
              padding: EdgeInsets.all(20.0),
              child: Text("Cathy"),
            ),
            Padding(
              padding: EdgeInsets.all(20.0),
              child: Text("Kenny"),
            ),
          ],
        ),
      ),
    );
  }
}